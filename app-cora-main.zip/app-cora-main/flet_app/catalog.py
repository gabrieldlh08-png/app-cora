CATEGORIES = [
    ("FLOOD", "Inundação"),
    ("RISK_HOUSING", "Risco de moradia"),
    ("LANDSLIDE", "Deslizamento de terra"),
    ("INFRASTRUCTURE_FAILURE", "Falha de infraestrutura"),
    ("OTHER", "Outro"),
]

STATUSES = [
    ("PENDING", "Pendente"),
    ("IN_PROGRESS", "Em andamento"),
    ("COMPLETED", "Concluído"),
    ("CANCELLED", "Cancelado"),
]

DEFAULT_STATUS = "PENDING"
