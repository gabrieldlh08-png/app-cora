import flet as ft

from . import theme as t
from .data import display_of


def is_narrow(page: ft.Page) -> bool:
    return (page.width or 400) < 700


def wrap_row(page: ft.Page, controls, spacing=12):
    if is_narrow(page):
        for control in controls:
            control.expand = False
        return ft.Column(controls, spacing=spacing)
    return ft.Row(controls, spacing=spacing)


def snack(page: ft.Page, message: str, error: bool = False):
    page.open(
        ft.SnackBar(
            content=ft.Text(message, color=t.WHITE),
            bgcolor="#B91C1C" if error else t.PRIMARY,
        )
    )


def field(label, password=False, multiline=False, value="", hint=""):
    return ft.TextField(
        label=label,
        password=password,
        can_reveal_password=password,
        multiline=multiline,
        min_lines=4 if multiline else 1,
        value=value or "",
        hint_text=hint,
        border_color="#94A3B8",
        focused_border_color=t.PRIMARY,
        bgcolor=t.WHITE,
        color=t.SLATE_900,
        label_style=ft.TextStyle(color=t.SLATE_900, weight=ft.FontWeight.W_600),
        dense=True,
        text_size=16,
        expand=False,
    )


def primary_button(text, on_click, expand=True):
    return ft.FilledButton(
        text,
        on_click=on_click,
        expand=expand,
        style=ft.ButtonStyle(
            bgcolor=t.PRIMARY,
            color=t.WHITE,
            padding=18,
            shape=ft.RoundedRectangleBorder(radius=8),
        ),
    )


def footer():
    return ft.Container(
        content=ft.Column(
            [
                ft.Row(
                    [
                        ft.Icon(ft.Icons.LOCATION_ON, color=t.WHITE, size=16),
                        ft.Text("Itapecerica da Serra - SP", color=t.WHITE, size=12, weight=ft.FontWeight.W_500),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    tight=True,
                ),
                ft.Text(
                    "C.O.R.A · Mapeamento colaborativo para comunidades mais seguras",
                    color="#FFFFFFBF",
                    size=10,
                    text_align=ft.TextAlign.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=4,
        ),
        padding=ft.padding.only(left=12, right=12, top=10, bottom=16),
        alignment=ft.Alignment(0, 0),
    )


def header(page: ft.Page, user, on_home, dark: bool):
    display_name, initials = display_of(user)
    colors = t.HEADER_ADMIN if user.is_staff else t.HEADER_USER
    narrow = is_narrow(page)
    menu = ft.PopupMenuButton(
        icon=ft.Icons.ARROW_DROP_DOWN,
        icon_color=t.WHITE,
        items=[
            ft.PopupMenuItem(text=display_name),
            ft.PopupMenuItem(text=user.email or user.username),
            ft.PopupMenuItem(),
            ft.PopupMenuItem(
                text="Sair",
                icon=ft.Icons.LOGOUT,
                on_click=lambda e: logout(page),
            ),
        ],
    )
    theme_btn = ft.IconButton(
        icon=ft.Icons.LIGHT_MODE if dark else ft.Icons.DARK_MODE,
        icon_color=t.WHITE,
        tooltip="Alternar tema",
        icon_size=20,
        on_click=lambda e: toggle_theme(page),
    )
    brand_texts = [ft.Text("C.O.R.A", color=t.WHITE, weight=ft.FontWeight.BOLD, size=16)]
    if not narrow:
        brand_texts.append(
            ft.Text(
                "Central de Organização para Realocação e Acolhimento",
                color="#FFFFFFCC",
                size=10,
                max_lines=1,
                overflow=ft.TextOverflow.ELLIPSIS,
            )
        )
    return ft.Container(
        content=ft.Row(
            [
                ft.GestureDetector(
                    on_tap=lambda e: on_home(),
                    expand=True,
                    content=ft.Row(
                        [
                            ft.Container(
                                content=ft.Icon(ft.Icons.SHIELD, color="#D1FAE5", size=18),
                                width=36,
                                height=36,
                                bgcolor="#064E3B80",
                                border_radius=8,
                                alignment=ft.Alignment(0, 0),
                            ),
                            ft.Column(brand_texts, spacing=0, expand=True),
                        ],
                        spacing=8,
                        expand=True,
                    ),
                ),
                ft.Row(
                    [
                        theme_btn,
                        ft.CircleAvatar(content=ft.Text(initials, size=11, weight=ft.FontWeight.BOLD), radius=14, bgcolor="#FFFFFF33"),
                        ft.Text(display_name, color=t.WHITE, size=13, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS) if not narrow else ft.Container(),
                        menu,
                    ],
                    spacing=0,
                    tight=True,
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        gradient=ft.LinearGradient(begin=ft.Alignment(-1, 0), end=ft.Alignment(1, 0), colors=colors),
        padding=ft.padding.symmetric(horizontal=10, vertical=8),
    )


def logout(page: ft.Page):
    page.session.remove("user_id")
    page.session.remove("access")
    page.session.remove("refresh")
    page.session.remove("user")
    page.go("/login")


def toggle_theme(page: ft.Page):
    dark = page.theme_mode == ft.ThemeMode.DARK
    page.theme_mode = ft.ThemeMode.LIGHT if dark else ft.ThemeMode.DARK
    page.client_storage.set("theme", "dark" if not dark else "light")
    page.go(page.route)


def shell(page, user, body, route_home="/"):
    dark = page.theme_mode == ft.ThemeMode.DARK
    bg = t.ADMIN_BG if user.is_staff else (t.ADMIN_BG if dark and not user.is_staff else t.USER_BG)
    if user.is_staff:
        bg = t.ADMIN_BG
    elif dark:
        bg = "#0B1220"
    else:
        bg = t.USER_BG
    header_bar = header(page, user, lambda: page.go("/"), dark)
    foot = footer()
    foot.gradient = ft.LinearGradient(
        begin=ft.Alignment(-1, 0),
        end=ft.Alignment(1, 0),
        colors=t.HEADER_ADMIN if user.is_staff else t.HEADER_USER,
    )
    pad = 10 if is_narrow(page) else 16
    return ft.View(
        route=page.route,
        padding=0,
        bgcolor=bg,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.SafeArea(
                ft.Column(
                    [
                        header_bar,
                        ft.Container(
                            content=body,
                            expand=True,
                            padding=pad,
                            alignment=ft.Alignment(0, -1),
                        ),
                        foot,
                    ],
                    expand=True,
                    spacing=0,
                ),
                expand=True,
            )
        ],
    )


def back_title(page, title, back_route, admin=False, extra=None):
    color = t.WHITE if admin or page.theme_mode == ft.ThemeMode.DARK else t.SLATE_900
    muted = t.SLATE_300 if admin or page.theme_mode == ft.ThemeMode.DARK else t.SLATE_600
    row = [
        ft.Column(
            [
                ft.TextButton("← Voltar", on_click=lambda e: page.go(back_route), style=ft.ButtonStyle(color=muted)),
                ft.Text(title, size=20 if is_narrow(page) else 22, weight=ft.FontWeight.BOLD, color=color),
            ],
            spacing=0,
            expand=True,
        )
    ]
    if extra:
        if is_narrow(page):
            return ft.Column(row + [extra], spacing=8)
        row.append(extra)
    return ft.Row(row, vertical_alignment=ft.CrossAxisAlignment.END, wrap=True)


def tile(title, subtitle, icon, colors, on_click):
    return ft.Container(
        content=ft.Column(
            [
                ft.Icon(icon, color=t.WHITE, size=26),
                ft.Container(expand=True),
                ft.Text(title, color=t.WHITE, size=16, weight=ft.FontWeight.W_600, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                ft.Text(subtitle, color="#FFFFFFCC", size=12, max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
            ],
            expand=True,
        ),
        gradient=ft.LinearGradient(begin=ft.Alignment(-1, 0), end=ft.Alignment(1, 0), colors=colors),
        border_radius=16,
        padding=16,
        height=120,
        expand=True,
        on_click=on_click,
        ink=True,
    )


def admin_row(icon, color, title, subtitle, on_click, trailing=None):
    return ft.Container(
        content=ft.Row(
            [
                ft.Container(
                    content=ft.Icon(icon, color=color, size=22),
                    width=40,
                    height=40,
                    bgcolor=color + "33",
                    border_radius=20,
                    alignment=ft.Alignment(0, 0),
                ),
                ft.Column(
                    [
                        ft.Text(title, color=t.WHITE, weight=ft.FontWeight.W_500, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.Text(subtitle, color=t.SLATE_400, size=12, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                    ],
                    spacing=2,
                    expand=True,
                ),
                trailing or ft.Container(),
            ],
            spacing=12,
        ),
        bgcolor=t.ADMIN_CARD,
        padding=16,
        border_radius=16,
        on_click=on_click,
        ink=True,
    )
