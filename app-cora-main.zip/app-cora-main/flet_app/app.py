import flet as ft

from . import catalog
from . import data
from . import theme as t
from .ui import (
    admin_row,
    back_title,
    field,
    footer,
    is_narrow,
    primary_button,
    shell,
    snack,
    tile,
    wrap_row,
)

def current_user(page: ft.Page):
    return data.as_user(page.session.get("user"))


def require_user(page: ft.Page):
    user = current_user(page)
    if not user:
        page.go("/login")
    return user


def login_view(page: ft.Page):
    email = field("Email", hint="seu@email.com")
    password = field("Senha", password=True, hint="••••••••")
    error = ft.Text("", color="#B91C1C", size=13)

    def submit(e):
        user = data.login_user(page, email.value, password.value)
        if not user:
            error.value = "Email ou senha inválidos. Confira se a API está no ar."
            page.update()
            return
        page.go("/")

    brand = ft.Container(
        content=ft.Row(
            [
                ft.Container(
                    content=ft.Icon(ft.Icons.SHIELD, color=t.WHITE, size=22),
                    width=44,
                    height=44,
                    bgcolor=t.PRIMARY,
                    border_radius=10,
                    alignment=ft.Alignment(0, 0),
                ),
                ft.Column(
                    [
                        ft.Text("C.O.R.A", size=20, weight=ft.FontWeight.BOLD, color=t.SLATE_900),
                        ft.Text(
                            "Central de Organização para Realocação e Acolhimento",
                            size=11,
                            color=t.SLATE_600,
                        ),
                    ],
                    spacing=2,
                    expand=True,
                ),
            ],
            spacing=12,
            expand=True,
        ),
        bgcolor=t.WHITE,
        padding=20,
        border=ft.border.only(bottom=ft.BorderSide(1, "#E2E8F0")),
    )
    card = ft.Container(
        content=ft.Column(
            [
                brand,
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text("Bem-vindo(a) de volta", size=20, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER, color=t.WHITE),
                            ft.Text("Acesse sua conta para continuar", color=t.SLATE_300, text_align=ft.TextAlign.CENTER),
                            error,
                            email,
                            password,
                            primary_button("Entrar", submit),
                            ft.Row(
                                [
                                    ft.Text("Não tem uma conta?", color=t.SLATE_300, size=13),
                                    ft.TextButton("Cadastre-se", on_click=lambda e: page.go("/register")),
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                                wrap=True,
                            ),
                        ],
                        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                        spacing=12,
                    ),
                    bgcolor="#0B1220",
                    padding=16 if is_narrow(page) else 24,
                ),
            ],
            spacing=0,
        ),
        border_radius=12,
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        shadow=ft.BoxShadow(blur_radius=24, color="#00000055"),
    )
    # form text on dark card should be light - override fields for login dark section
    email.bgcolor = "#111827"
    email.color = t.WHITE
    email.label_style = ft.TextStyle(color=t.WHITE)
    password.bgcolor = "#111827"
    password.color = t.WHITE
    password.label_style = ft.TextStyle(color=t.WHITE)

    body = ft.Column(
        [
            card,
            footer(),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        spacing=16,
    )
    return ft.View(
        "/login",
        padding=10,
        bgcolor=t.LOGIN_MID,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.SafeArea(
                ft.Container(
                    content=body,
                    expand=True,
                    gradient=ft.LinearGradient(
                        begin=ft.Alignment(0, -1),
                        end=ft.Alignment(0, 1),
                        colors=[t.LOGIN_TOP, t.LOGIN_MID, t.LOGIN_BOTTOM],
                    ),
                ),
                expand=True,
            )
        ],
    )


def register_view(page: ft.Page):
    first = field("Nome")
    last = field("Sobrenome")
    email = field("Email", hint="seu@email.com")
    cpf = field("CPF", hint="000.000.000-00")
    phone = field("Telefone", hint="(11) 90000-0000")
    cep = field("CEP", hint="00000-000")
    address = field("Endereço")
    number = field("Número")
    neighborhood = field("Bairro")
    city = field("Cidade")
    password1 = field("Senha", password=True)
    password2 = field("Confirmar senha", password=True)
    status = ft.Text("", size=13, color=t.SLATE_600)
    error = ft.Text("", color="#B91C1C", size=13)

    def on_cpf(e):
        cpf.value = data.mask_cpf(cpf.value)
        page.update()

    def on_phone(e):
        phone.value = data.mask_phone(phone.value)
        page.update()

    def on_cep(e):
        cep.value = data.mask_cep(cep.value)
        digits = data.only_digits(cep.value)
        if len(digits) == 8:
            found = data.lookup_cep(digits)
            if found:
                address.value = found["address"]
                neighborhood.value = found["neighborhood"]
                city.value = found["city"]
                cep.value = data.mask_cep(found["zip_code"] or digits)
                status.value = "Endereço preenchido. Confira os dados."
                status.color = t.SLATE_600
            else:
                status.value = "CEP não encontrado."
                status.color = "#B91C1C"
        page.update()

    cpf.on_change = on_cpf
    phone.on_change = on_phone
    cep.on_change = on_cep
    cep.on_blur = on_cep

    def submit(e):
        payload = {
            "first_name": first.value,
            "last_name": last.value,
            "username": email.value,
            "cpf": cpf.value,
            "phone": phone.value,
            "zip_code": cep.value,
            "address": address.value,
            "number_street": number.value,
            "neighborhood": neighborhood.value,
            "city": city.value,
            "password1": password1.value,
            "password2": password2.value,
        }
        user, errors = data.register_user(page, payload)
        if errors:
            error.value = " ".join(errors)
            page.update()
            return
        page.go("/")

    form = ft.Column(
        [
            ft.Text("Crie sua conta", size=20, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER, color=t.WHITE),
            ft.Text("Preencha os dados para começar", color=t.SLATE_300, text_align=ft.TextAlign.CENTER),
            error,
            first,
            last,
            email,
            cpf,
            phone,
            cep,
            status,
            address,
            number,
            neighborhood,
            city,
            password1,
            password2,
            primary_button("Cadastrar", submit),
            ft.Row(
                [
                    ft.Text("Já tem uma conta?", color=t.SLATE_300, size=13),
                    ft.TextButton("Entrar", on_click=lambda e: page.go("/login")),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                wrap=True,
            ),
        ],
        spacing=10,
    )
    for control in [first, last, email, cpf, phone, cep, address, number, neighborhood, city, password1, password2]:
        control.bgcolor = "#111827"
        control.color = t.WHITE
        control.label_style = ft.TextStyle(color=t.WHITE)

    brand = ft.Container(
        content=ft.Row(
            [
                ft.Container(
                    content=ft.Icon(ft.Icons.SHIELD, color=t.WHITE, size=22),
                    width=44,
                    height=44,
                    bgcolor=t.PRIMARY,
                    border_radius=10,
                    alignment=ft.Alignment(0, 0),
                ),
                ft.Column(
                    [
                        ft.Text("C.O.R.A", size=20, weight=ft.FontWeight.BOLD, color=t.SLATE_900),
                        ft.Text("Central de Organização para Realocação e Acolhimento", size=11, color=t.SLATE_600),
                    ],
                    spacing=2,
                    expand=True,
                ),
            ],
            expand=True,
        ),
        bgcolor=t.WHITE,
        padding=20,
    )
    card = ft.Container(
        content=ft.Column([brand, ft.Container(form, padding=16, bgcolor="#0B1220")], spacing=0),
        border_radius=12,
        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
        shadow=ft.BoxShadow(blur_radius=24, color="#00000055"),
    )
    return ft.View(
        "/register",
        padding=10,
        bgcolor=t.LOGIN_MID,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.SafeArea(
                ft.Container(
                    content=ft.Column(
                        [card, footer()],
                        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                        spacing=12,
                    ),
                    expand=True,
                    gradient=ft.LinearGradient(
                        begin=ft.Alignment(0, -1),
                        end=ft.Alignment(0, 1),
                        colors=[t.LOGIN_TOP, t.LOGIN_MID, t.LOGIN_BOTTOM],
                    ),
                ),
                expand=True,
            )
        ],
    )


def home_user_view(page, user):
    stats = data.home_stats(page)
    text_color = t.WHITE if page.theme_mode == ft.ThemeMode.DARK else t.SLATE_900
    muted = t.SLATE_300 if page.theme_mode == ft.ThemeMode.DARK else t.SLATE_600
    recent = []
    if stats["incidents"]:
        for item in stats["incidents"]:
            recent.append(
                ft.ListTile(
                    title=ft.Text(item.title, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                    subtitle=ft.Text(f"{item.get_status_display()} · {item.created_at.strftime('%d/%m/%Y')}"),
                    trailing=ft.Icon(ft.Icons.CHEVRON_RIGHT),
                    dense=True,
                    on_click=lambda e, pk=item.pk: page.go(f"/denuncias/{pk}"),
                )
            )
    else:
        recent = [
            ft.Column(
                [
                    ft.Icon(ft.Icons.INFO, color=muted),
                    ft.Text("Nenhuma denúncia ainda", size=18, weight=ft.FontWeight.W_600, color=text_color),
                    ft.Text("Comece reportando uma área de risco na sua região", color=muted, size=13),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )
        ]
    body = ft.Column(
        [
            wrap_row(
                page,
                [
                    tile("Nova Denúncia", "Reportar risco", ft.Icons.ADD, t.TILE_NOVA, lambda e: page.go("/denuncias/nova")),
                    tile("Mapa", "Ver áreas de risco", ft.Icons.LOCATION_ON, t.TILE_MAPA, lambda e: page.go("/mapa")),
                ],
            ),
            wrap_row(
                page,
                [
                    tile("Minhas Denúncias", f"{stats['total']} registro(s)", ft.Icons.DESCRIPTION, t.TILE_MINHAS, lambda e: page.go("/denuncias")),
                    tile("Educação", "Aprenda mais", ft.Icons.MENU_BOOK, t.TILE_EDU, lambda e: page.go("/educacao")),
                ],
            ),
            ft.Text("Suas Estatísticas", size=18, weight=ft.FontWeight.W_600, color=text_color),
            wrap_row(
                page,
                [
                    _stat_card(str(stats["total"]), "Total", t.PRIMARY),
                    _stat_card(str(stats["pending"]), "Pendentes", "#F59E0B"),
                    _stat_card(str(stats["completed"]), "Resolvidas", t.PRIMARY),
                ],
            ),
            ft.Container(
                content=ft.Column(recent, spacing=4),
                bgcolor=t.WHITE if page.theme_mode != ft.ThemeMode.DARK else t.ADMIN_CARD,
                border_radius=12,
                padding=16,
            ),
        ],
        spacing=16,
        expand=True,
    )
    return shell(page, user, body)


def _stat_card(value, label, color):
    return ft.Container(
        content=ft.Column(
            [
                ft.Text(value, size=28, weight=ft.FontWeight.BOLD, color=color),
                ft.Text(label, size=13, color=t.SLATE_600),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        bgcolor=t.WHITE,
        padding=16,
        border_radius=12,
        expand=True,
    )


def _admin_stat(title, value, icon, colors):
    return ft.Container(
        content=ft.Row(
            [
                ft.Icon(icon, color=t.WHITE, size=20),
                ft.Text(title, color=t.WHITE, weight=ft.FontWeight.W_500, expand=True, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                ft.Text(str(value), size=24, weight=ft.FontWeight.BOLD, color=t.WHITE),
            ],
            spacing=8,
        ),
        gradient=ft.LinearGradient(begin=ft.Alignment(-1, 0), end=ft.Alignment(1, 0), colors=colors),
        padding=16,
        border_radius=16,
    )


def home_admin_view(page, user):
    stats = data.home_stats(page)
    body = ft.Column(
        [
            wrap_row(
                page,
                [
                    _admin_stat("Total de Denúncias", stats["total"], ft.Icons.DESCRIPTION, t.STAT_TOTAL),
                    _admin_stat("Prioridade Crítica", stats["critical"], ft.Icons.ERROR, t.STAT_CRITICAL),
                ],
            ),
            wrap_row(
                page,
                [
                    _admin_stat("Aguardando", stats["pending"], ft.Icons.SCHEDULE, t.STAT_WAIT),
                    _admin_stat("Resolvidas", stats["completed"], ft.Icons.CHECK_CIRCLE, t.STAT_DONE),
                ],
            ),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Row([ft.Icon(ft.Icons.SHOW_CHART, color=t.WHITE, size=16), ft.Text("Status das Denúncias", color=t.WHITE, weight=ft.FontWeight.W_600)]),
                        ft.Row([ft.Text("Em Análise", color=t.SLATE_300), ft.Text(str(stats["pending"]), color=t.SLATE_300)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        ft.Row([ft.Text("Em Atendimento", color=t.SLATE_300), ft.Text(str(stats["in_progress"]), color=t.SLATE_300)], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ],
                    spacing=10,
                ),
                bgcolor=t.ADMIN_CARD,
                padding=20,
                border_radius=16,
            ),
            ft.Text("Gerenciar Sistema", size=18, weight=ft.FontWeight.W_600, color=t.WHITE),
            admin_row(
                ft.Icons.DESCRIPTION,
                "#34D399",
                "Gerenciar Denúncias",
                "Visualizar, filtrar e atualizar status",
                lambda e: page.go("/denuncias"),
                ft.Container(
                    content=ft.Text(str(stats["total"]), color=t.WHITE, weight=ft.FontWeight.BOLD),
                    bgcolor=t.GREEN,
                    padding=ft.padding.symmetric(horizontal=8, vertical=4),
                    border_radius=20,
                ),
            ),
            admin_row(ft.Icons.LOCATION_ON, "#2DD4BF", "Mapa Administrativo", "Visualizar pontos de risco no mapa", lambda e: page.go("/mapa")),
            admin_row(ft.Icons.NOTIFICATIONS, "#FB923C", "Enviar Alertas", "Notificar moradores sobre emergências", lambda e: page.go("/alertas")),
            admin_row(ft.Icons.BAR_CHART, "#22D3EE", "Relatórios", "Estatísticas e análises detalhadas", lambda e: page.go("/relatorios")),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def list_view(page, user):
    items = data.list_incidents(page)
    admin = user.is_staff
    title = "Gerenciar Denúncias" if admin else "Minhas Denúncias"
    rows = []
    for item in items:
        extra = f" · {item.reported_by.get_full_name() or item.reported_by.username}" if admin else ""
        rows.append(
            ft.Container(
                content=ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text(item.title, weight=ft.FontWeight.W_500, color=t.SLATE_900, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                                ft.Text(
                                    f"{item.get_category_display()} · {item.get_status_display()}{extra} · {item.created_at.strftime('%d/%m/%Y %H:%M')}",
                                    size=12,
                                    color=t.SLATE_600,
                                    max_lines=2,
                                    overflow=ft.TextOverflow.ELLIPSIS,
                                ),
                            ],
                            expand=True,
                            spacing=4,
                        ),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=t.SLATE_400),
                    ]
                ),
                padding=16,
                border=ft.border.only(bottom=ft.BorderSide(1, "#F1F5F9")),
                on_click=lambda e, pk=item.pk: page.go(f"/denuncias/{pk}"),
            )
        )
    if not rows:
        rows = [ft.Container(content=ft.Text("Nenhuma denúncia encontrada", color=t.SLATE_600), padding=40, alignment=ft.Alignment(0, 0))]
    extra = None
    if not admin:
        extra = ft.FilledButton("Nova", icon=ft.Icons.ADD, on_click=lambda e: page.go("/denuncias/nova"), style=ft.ButtonStyle(bgcolor=t.PRIMARY, color=t.WHITE))
    body = ft.Column(
        [
            back_title(page, title, "/", admin, extra),
            ft.Container(content=ft.Column(rows, spacing=0), bgcolor=t.WHITE, border_radius=12, clip_behavior=ft.ClipBehavior.ANTI_ALIAS),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def form_view(page, user, incident_id=None):
    incident = data.get_incident(page, int(incident_id)) if incident_id else None
    if incident_id and not incident:
        page.go("/denuncias")
        return shell(page, user, ft.Text("Não encontrado"))
    photos = []
    title = field("Título", value=incident.title if incident else "", hint="Resumo da denúncia")
    description = field("Descrição", multiline=True, value=incident.description if incident else "", hint="Descreva o que aconteceu")
    category = ft.Dropdown(
        label="Categoria",
        options=[ft.dropdown.Option(key=v, text=l) for v, l in catalog.CATEGORIES],
        value=incident.category if incident else None,
        bgcolor=t.WHITE,
        color=t.SLATE_900,
        filled=True,
        dense=True,
        text_size=16,
        border_color="#94A3B8",
    )
    status = ft.Dropdown(
        label="Status",
        options=[ft.dropdown.Option(key=v, text=l) for v, l in catalog.STATUSES],
        value=incident.status if incident else catalog.DEFAULT_STATUS,
        bgcolor=t.WHITE,
        filled=True,
        dense=True,
        text_size=16,
        border_color="#94A3B8",
        visible=user.is_staff,
        color=t.SLATE_900,
    )
    address = field("Endereço", value=incident.address if incident else "", hint="Endereço da ocorrência")
    location = field("Localização atual", value=incident.now_location if incident else "", hint="Endereço, bairro ou lat, lng")
    loc_status = ft.Text("", size=12, color=t.SLATE_600)
    photo_label = ft.Text("Nenhuma foto nova selecionada.", size=12, color=t.SLATE_600)

    def on_files(e: ft.FilePickerResultEvent):
        photos.clear()
        if e.files:
            photos.extend([f.path for f in e.files if f.path])
            photo_label.value = f"{len(photos)} foto(s) selecionada(s)."
        page.update()

    picker = next((c for c in page.overlay if isinstance(c, ft.FilePicker)), None)
    if picker:
        picker.on_result = on_files

    def locate(e):
        found = data.geocode(page, address.value, location.value)
        if found:
            location.value = f"{found[0]}, {found[1]}"
            loc_status.value = "Localização obtida a partir do endereço."
            loc_status.color = t.PRIMARY
        else:
            loc_status.value = "Não foi possível localizar o endereço."
            loc_status.color = "#B91C1C"
        page.update()

    def save(e):
        if not title.value or not description.value or not category.value or not address.value or not location.value:
            snack(page, "Preencha todos os campos obrigatórios.", True)
            return
        payload = {
            "title": title.value.strip(),
            "description": description.value.strip(),
            "category": category.value,
            "status": status.value,
            "address": address.value.strip(),
            "now_location": location.value.strip(),
        }
        try:
            _, alerted, count = data.save_incident(page, payload, incident, photos)
        except data.ApiError as exc:
            snack(page, exc.message, True)
            return
        if alerted:
            snack(page, f"Ocorrência confirmada. Alerta enviado para {count} morador(es).")
        else:
            snack(page, "Denúncia salva.")
        page.go("/denuncias")

    current_photos = []
    if incident:
        for photo in incident.photos.all():
            current_photos.append(ft.Image(src=photo.image.path or photo.image.url, width=110, height=80, fit=ft.ImageFit.COVER, border_radius=8))

    heading = "Editar denúncia" if incident else "Nova denúncia"
    body = ft.Column(
        [
            back_title(page, heading, "/denuncias", user.is_staff),
            ft.Container(
                content=ft.Column(
                    [
                        title,
                        description,
                        category,
                        status if user.is_staff else ft.Container(),
                        address,
                        location,
                        ft.FilledButton(
                            "Usar localização do endereço",
                            icon=ft.Icons.MY_LOCATION,
                            on_click=locate,
                            expand=True,
                            style=ft.ButtonStyle(bgcolor=t.PRIMARY, color=t.WHITE),
                        ),
                        loc_status,
                        ft.Text("Fotos atuais", weight=ft.FontWeight.W_600, color=t.SLATE_900) if current_photos else ft.Container(),
                        ft.Row(current_photos, wrap=True) if current_photos else ft.Container(),
                        ft.FilledButton(
                            "Selecionar fotos",
                            icon=ft.Icons.PHOTO,
                            expand=True,
                            on_click=lambda e: picker.pick_files(allow_multiple=True, allowed_extensions=["png", "jpg", "jpeg", "webp"]) if picker else None,
                        ),
                        photo_label,
                        primary_button("Salvar alterações" if incident else "Registrar denúncia", save),
                    ],
                    spacing=12,
                ),
                bgcolor=t.WHITE,
                padding=12 if is_narrow(page) else 20,
                border_radius=12,
            ),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def map_view(page, user):
    points = data.map_points(page)
    cards = []
    for point in points:
        url = f"https://www.openstreetmap.org/?mlat={point['lat']}&mlon={point['lng']}#map=16/{point['lat']}/{point['lng']}"
        cards.append(
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text(point["title"], weight=ft.FontWeight.W_600, color=t.SLATE_900, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.Text(f"{point['category']} · {point['status']}", size=12, color=t.SLATE_600, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.Text(point["address"], size=12, color=t.SLATE_600, max_lines=3, overflow=ft.TextOverflow.ELLIPSIS),
                        ft.TextButton("Abrir no mapa", on_click=lambda e, link=url: page.launch_url(link)),
                    ],
                    spacing=4,
                ),
                bgcolor=t.WHITE,
                padding=16,
                border_radius=12,
            )
        )
    if not cards:
        cards = [ft.Text("Nenhum ponto com localização.", color=t.SLATE_400)]
    city = "https://www.openstreetmap.org/#map=13/-23.7175/-46.8494"
    heading = "Mapa Administrativo" if user.is_staff else "Mapa de riscos"
    body = ft.Column(
        [
            back_title(page, heading, "/", user.is_staff),
            ft.Text(f"{len(points)} ponto(s) com localização", color=t.SLATE_300 if user.is_staff else t.SLATE_600, size=13),
            ft.FilledButton(
                "Abrir mapa da cidade",
                icon=ft.Icons.MAP,
                expand=True,
                on_click=lambda e: page.launch_url(city),
                style=ft.ButtonStyle(bgcolor=t.PRIMARY, color=t.WHITE),
            ),
            *cards,
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def education_view(page, user):
    body = ft.Column(
        [
            back_title(page, "Educação", "/", user.is_staff),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text("Como se proteger", size=18, weight=ft.FontWeight.W_600, color=t.SLATE_900),
                        ft.Text("Em caso de inundação, evite áreas alagadas e procure um ponto alto."),
                        ft.Text("Deslizamentos: saia imediatamente se houver rachaduras ou barulho no terreno."),
                        ft.Text("Use o C.O.R.A para reportar riscos e acompanhar o atendimento da denúncia."),
                    ],
                    spacing=10,
                ),
                bgcolor=t.WHITE,
                padding=20,
                border_radius=12,
            ),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def alerts_view(page, user):
    if not user.is_staff:
        page.go("/")
        return shell(page, user, ft.Text(""))
    info = data.reports_data(page)
    rows = []
    for item in info["in_progress"]:
        rows.append(
            ft.Container(
                content=ft.Row(
                    [
                        ft.Column(
                            [
                                ft.Text(item.title, color=t.WHITE, weight=ft.FontWeight.W_500, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                                ft.Text(f"{item.get_category_display()} · {item.address}", color=t.SLATE_400, size=12, max_lines=2, overflow=ft.TextOverflow.ELLIPSIS),
                            ],
                            expand=True,
                        ),
                        ft.Text("Confirmada", color="#34D399", size=12),
                    ]
                ),
                padding=16,
                on_click=lambda e, pk=item.pk: page.go(f"/denuncias/{pk}"),
            )
        )
    body = ft.Column(
        [
            back_title(page, "Enviar Alertas", "/", True),
            ft.Container(
                content=ft.Column(
                    [
                        ft.Text("Como funciona", color=t.WHITE, weight=ft.FontWeight.W_600),
                        ft.Text(
                            "Quando um órgão superior confirma a ocorrência e o status muda para Em andamento, o C.O.R.A envia um e-mail automático para os moradores cadastrados.",
                            color=t.SLATE_300,
                        ),
                        ft.Text(f"Destinatários atuais: {info['recipients']} e-mail(s).", color=t.SLATE_400, size=13),
                        ft.TextButton("Atualizar status de uma denúncia", on_click=lambda e: page.go("/denuncias")),
                    ],
                    spacing=8,
                ),
                bgcolor=t.ADMIN_CARD,
                padding=20,
                border_radius=16,
            ),
            ft.Text("Ocorrências em andamento", color=t.WHITE, size=18, weight=ft.FontWeight.W_600),
            ft.Container(content=ft.Column(rows or [ft.Text("Nenhuma ocorrência confirmada no momento.", color=t.SLATE_400)], spacing=0), bgcolor=t.ADMIN_CARD, border_radius=16),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def reports_view(page, user):
    if not user.is_staff:
        page.go("/")
        return shell(page, user, ft.Text(""))
    info = data.reports_data(page)
    pie = ft.PieChart(
        sections=[
            ft.PieChartSection(value=max(v, 0.01), title=str(v), color=t.STATUS_COLORS[i % 4], radius=55, title_style=ft.TextStyle(size=12, color=t.WHITE, weight=ft.FontWeight.BOLD))
            for i, (label, v) in enumerate(info["status"])
        ],
        sections_space=2,
        center_space_radius=30,
        height=180,
    )
    max_cat = max([v for _, v in info["category"]] or [1])
    bars = ft.BarChart(
        bar_groups=[
            ft.BarChartGroup(
                x=i,
                bar_rods=[ft.BarChartRod(from_y=0, to_y=v, width=18, color="#34D399", border_radius=4)],
            )
            for i, (_, v) in enumerate(info["category"])
        ],
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(value=i, label=ft.Text(label[:8], size=9, color=t.SLATE_300))
                for i, (label, _) in enumerate(info["category"])
            ]
        ),
        left_axis=ft.ChartAxis(labels_size=30),
        max_y=max(max_cat, 1) + 1,
        height=200,
    )
    line = ft.LineChart(
        data_series=[
            ft.LineChartData(
                data_points=[ft.LineChartDataPoint(i, v) for i, (_, v) in enumerate(info["trend"])],
                color="#22C55E",
                stroke_width=3,
                curved=True,
                below_line_bgcolor="#22C55E30",
            )
        ],
        bottom_axis=ft.ChartAxis(
            labels=[
                ft.ChartAxisLabel(value=i, label=ft.Text(label, size=11, color=t.SLATE_300))
                for i, (label, _) in enumerate(info["trend"])
            ]
        ),
        min_y=0,
        max_y=max([v for _, v in info["trend"]] or [1]) + 1,
        height=200,
    )
    body = ft.Column(
        [
            back_title(page, "Relatórios", "/", True),
            ft.Text(f"{info['total']} ocorrência(s) registrada(s)", color=t.SLATE_400, size=13),
            ft.Container(content=ft.Column([ft.Text("Ocorrências por status", color=t.WHITE, weight=ft.FontWeight.W_600), pie]), bgcolor=t.ADMIN_CARD, padding=16, border_radius=16),
            ft.Container(content=ft.Column([ft.Text("Ocorrências por categoria", color=t.WHITE, weight=ft.FontWeight.W_600), bars]), bgcolor=t.ADMIN_CARD, padding=16, border_radius=16),
            ft.Container(content=ft.Column([ft.Text("Novas denúncias nos últimos 6 meses", color=t.WHITE, weight=ft.FontWeight.W_600), line]), bgcolor=t.ADMIN_CARD, padding=16, border_radius=16),
        ],
        spacing=12,
        expand=True,
    )
    return shell(page, user, body)


def main(page: ft.Page):
    page.title = "C.O.R.A"
    page.theme = ft.Theme(color_scheme_seed=t.PRIMARY)
    stored = page.client_storage.get("theme")
    page.theme_mode = ft.ThemeMode.DARK if stored == "dark" else ft.ThemeMode.LIGHT
    page.padding = 0
    page.overlay.append(ft.FilePicker())
    page.session.set("narrow", is_narrow(page))

    def on_resize(e):
        narrow = is_narrow(page)
        if page.session.get("narrow") != narrow:
            page.session.set("narrow", narrow)
            page.go(page.route)

    page.on_resized = on_resize

    def route_change(e):
        route = page.route or "/"
        page.views.clear()
        if route in ("/login", "/register"):
            page.views.append(login_view(page) if route == "/login" else register_view(page))
            page.update()
            return
        user = current_user(page)
        if not user:
            page.go("/login")
            return
        try:
            if route == "/denuncias":
                page.views.append(list_view(page, user))
            elif route == "/denuncias/nova":
                page.views.append(form_view(page, user))
            elif route.startswith("/denuncias/"):
                pk = route.rsplit("/", 1)[-1]
                page.views.append(form_view(page, user, pk))
            elif route == "/mapa":
                page.views.append(map_view(page, user))
            elif route == "/educacao":
                page.views.append(education_view(page, user))
            elif route == "/alertas":
                page.views.append(alerts_view(page, user))
            elif route == "/relatorios":
                page.views.append(reports_view(page, user))
            else:
                page.views.append(home_admin_view(page, user) if user.is_staff else home_user_view(page, user))
        except data.ApiError as exc:
            snack(page, exc.message, True)
            page.views.append(login_view(page) if not page.session.get("access") else shell(page, user, ft.Text(exc.message)))
        page.update()

    page.on_route_change = route_change
    page.go("/login" if not current_user(page) else "/")


if __name__ == "__main__":
    ft.app(target=main, view=ft.AppView.WEB_BROWSER)
