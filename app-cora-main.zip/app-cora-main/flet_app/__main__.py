from .app import main
import flet as ft

ft.app(target=main, view=ft.AppView.WEB_BROWSER)
