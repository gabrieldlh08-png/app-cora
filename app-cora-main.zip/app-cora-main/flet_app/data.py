import os
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

API_BASE = os.environ.get("CORA_API_URL", "http://127.0.0.1:8000/api").rstrip("/")


class ApiError(Exception):
    def __init__(self, message, errors=None):
        super().__init__(message)
        self.message = message
        self.errors = errors or [message]


class ApiUser:
    def __init__(self, payload: dict):
        self.id = payload.get("id")
        self.pk = self.id
        self.username = payload.get("username") or ""
        self.email = payload.get("email") or self.username
        self.first_name = payload.get("first_name") or ""
        self.last_name = payload.get("last_name") or ""
        self.is_staff = bool(payload.get("is_staff"))
        self.full_name = payload.get("full_name") or ""

    def get_full_name(self):
        return self.full_name or f"{self.first_name} {self.last_name}".strip()


class IncidentObj:
    def __init__(self, payload: dict):
        self._data = payload
        self.pk = payload.get("id")
        self.id = self.pk
        self.title = payload.get("title") or ""
        self.description = payload.get("description") or ""
        self.category = payload.get("category") or ""
        self.status = payload.get("status") or ""
        self.address = payload.get("address") or ""
        self.now_location = payload.get("now_location") or ""
        self.created_at = _parse_dt(payload.get("created_at"))
        reporter = payload.get("reported_by") or {}
        full_name = reporter.get("full_name") or ""
        self.reported_by = SimpleNamespace(
            username=reporter.get("username") or "",
            get_full_name=lambda: full_name,
        )
        self.photos = SimpleNamespace(
            all=lambda: [
                SimpleNamespace(image=SimpleNamespace(path=photo.get("url") or "", url=photo.get("url") or ""))
                for photo in payload.get("photos") or []
            ]
        )

    def get_category_display(self):
        return self._data.get("category_display") or self.category

    def get_status_display(self):
        return self._data.get("status_display") or self.status


def _parse_dt(value):
    if not value:
        return datetime.now()
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return datetime.now()


def display_of(user) -> tuple[str, str]:
    full_name = (getattr(user, "full_name", None) or user.get_full_name() or "").strip()
    display_name = full_name or user.first_name or user.username
    if user.first_name and user.last_name:
        initials = f"{user.first_name[0]}{user.last_name[0]}".upper()
    elif user.first_name:
        initials = user.first_name[:2].upper()
    else:
        initials = (user.username or "CO")[:2].upper()
    return display_name, initials


def as_user(payload: dict | None):
    if not payload:
        return None
    return ApiUser(payload)


def token_of(page):
    return page.session.get("access")


def _headers(page=None, json_body=True):
    headers = {}
    if json_body:
        headers["Content-Type"] = "application/json"
    token = token_of(page) if page is not None else None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


def _request(method, path, page=None, **kwargs):
    url = f"{API_BASE}{path}"
    headers = kwargs.pop("headers", None) or _headers(page, json_body="json" in kwargs)
    try:
        response = requests.request(method, url, headers=headers, timeout=20, **kwargs)
    except requests.RequestException as exc:
        raise ApiError(f"Não foi possível conectar à API ({API_BASE}).") from exc
    if response.status_code == 401:
        if page is not None:
            page.session.remove("access")
            page.session.remove("refresh")
            page.session.remove("user")
        raise ApiError("Sessão expirada. Entre novamente.")
    if response.status_code >= 400:
        payload = _safe_json(response)
        errors = payload.get("errors")
        detail = payload.get("detail")
        if errors:
            raise ApiError(" ".join(str(item) for item in errors), errors)
        if isinstance(detail, list):
            raise ApiError(" ".join(str(item) for item in detail), detail)
        if detail:
            raise ApiError(str(detail))
        raise ApiError("Não foi possível concluir a operação.")
    if response.status_code == 204 or not response.content:
        return {}
    return _safe_json(response)


def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        return {}


def _store_auth(page, payload):
    page.session.set("access", payload.get("access"))
    page.session.set("refresh", payload.get("refresh"))
    page.session.set("user", payload.get("user"))
    return as_user(payload.get("user"))


def login_user(page, email: str, password: str):
    try:
        payload = _request(
            "POST",
            "/auth/login/",
            json={"email": (email or "").strip(), "password": password or ""},
        )
    except ApiError:
        return None
    return _store_auth(page, payload)


def register_user(page, payload: dict):
    try:
        data = _request("POST", "/auth/register/", json=payload)
    except ApiError as exc:
        return None, exc.errors
    return _store_auth(page, data), []


def lookup_cep(zip_code: str):
    digits = only_digits(zip_code)
    try:
        return _request("GET", f"/cep/{digits}/")
    except ApiError:
        return None


def home_stats(page):
    payload = _request("GET", "/home/", page)
    payload["incidents"] = [IncidentObj(item) for item in payload.get("incidents") or []]
    return payload


def list_incidents(page):
    return [IncidentObj(item) for item in _request("GET", "/incidents/", page)]


def get_incident(page, pk: int):
    try:
        return IncidentObj(_request("GET", f"/incidents/{pk}/", page))
    except ApiError:
        return None


def save_incident(page, data: dict, incident=None, photo_paths=None):
    incident_id = incident.pk if incident else None
    files = []
    handles = []
    try:
        for path in photo_paths or []:
            handle = open(path, "rb")
            handles.append(handle)
            files.append(("photos", (os.path.basename(path), handle, "application/octet-stream")))
        if files:
            body = {key: value for key, value in data.items() if value is not None}
            if incident_id:
                payload = _request(
                    "PATCH",
                    f"/incidents/{incident_id}/",
                    page,
                    data=body,
                    files=files,
                    headers=_headers(page, json_body=False),
                )
            else:
                payload = _request(
                    "POST",
                    "/incidents/",
                    page,
                    data=body,
                    files=files,
                    headers=_headers(page, json_body=False),
                )
        else:
            if incident_id:
                payload = _request("PATCH", f"/incidents/{incident_id}/", page, json=data)
            else:
                payload = _request("POST", "/incidents/", page, json=data)
    finally:
        for handle in handles:
            handle.close()
    saved = IncidentObj(payload.get("incident") or {})
    return saved, bool(payload.get("alert_sent")), int(payload.get("alert_recipients") or 0)


def map_points(page):
    return _request("GET", "/map/", page)


def reports_data(page):
    payload = _request("GET", "/reports/", page)
    payload["in_progress"] = [IncidentObj(item) for item in payload.get("in_progress") or []]
    payload["status"] = [tuple(item) for item in payload.get("status") or []]
    payload["category"] = [tuple(item) for item in payload.get("category") or []]
    payload["trend"] = [tuple(item) for item in payload.get("trend") or []]
    return payload


def geocode(page, address, now_location):
    try:
        payload = _request(
            "POST",
            "/geocode/",
            page,
            json={"address": address or "", "now_location": now_location or ""},
        )
    except ApiError:
        return None
    return payload.get("lat"), payload.get("lng")


def only_digits(value: str) -> str:
    return "".join(ch for ch in (value or "") if ch.isdigit())


def mask_cpf(value: str) -> str:
    numbers = only_digits(value)[:11]
    out = ""
    pattern = "000.000.000-00"
    i = 0
    for char in pattern:
        if i >= len(numbers):
            break
        if char == "0":
            out += numbers[i]
            i += 1
        else:
            out += char
    return out


def mask_cep(value: str) -> str:
    numbers = only_digits(value)[:8]
    if len(numbers) <= 5:
        return numbers
    return f"{numbers[:5]}-{numbers[5:]}"


def mask_phone(value: str) -> str:
    numbers = only_digits(value)[:11]
    if len(numbers) > 10:
        pattern = "(00) 00000-0000"
    else:
        pattern = "(00) 0000-0000"
    out = ""
    i = 0
    for char in pattern:
        if i >= len(numbers):
            break
        if char == "0":
            out += numbers[i]
            i += 1
        else:
            out += char
    return out
