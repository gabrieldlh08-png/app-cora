# O app Flet não inicia o Django localmente: ele consome a API em CORA_API_URL.
