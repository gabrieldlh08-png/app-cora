from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views import View

from services.viacep import ViaCEP

from .forms import RegisterForm


class LoginView(View):
    template_name = "authentication/login.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect("home")
        return render(request, self.template_name, {"form": AuthenticationForm()})

    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            next_url = request.GET.get("next") or "home"
            return redirect(next_url)
        return render(request, self.template_name, {"form": form}, status=400)


class RegisterView(View):
    template_name = "authentication/register.html"

    def get(self, request):
        if request.user.is_authenticated:
            return redirect("home")
        return render(request, self.template_name, {"form": RegisterForm()})

    def post(self, request):
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("home")
        return render(request, self.template_name, {"form": form}, status=400)


class ZipCodeLookupView(View):
    def get(self, request):
        data = ViaCEP().get_address(request.GET.get("zip_code", ""))
        if not data:
            return JsonResponse({"ok": False, "error": "CEP não encontrado."}, status=404)
        return JsonResponse(
            {
                "ok": True,
                "address": data.get("logradouro") or "",
                "neighborhood": data.get("bairro") or "",
                "city": data.get("localidade") or "",
                "zip_code": data.get("cep") or "",
            }
        )
