from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.db import transaction

from accounts.models import Profile


class RegisterForm(UserCreationForm):
    username = forms.EmailField(
        label="Email",
        max_length=254,
        error_messages={
            "unique": "Já existe uma conta com este email.",
        },
    )
    first_name = forms.CharField(label="Nome", max_length=150)
    last_name = forms.CharField(label="Sobrenome", max_length=150)
    phone = forms.CharField(label="Telefone", max_length=15)
    cpf = forms.CharField(label="CPF", max_length=14)
    address = forms.CharField(label="Endereço", max_length=255)
    number_street = forms.CharField(label="Número", max_length=10)
    neighborhood = forms.CharField(label="Bairro", max_length=150)
    city = forms.CharField(label="Cidade", max_length=150)
    zip_code = forms.CharField(label="CEP", max_length=10)

    class Meta:
        model = User
        fields = ("first_name", "last_name", "username")

    def clean_cpf(self):
        cpf = self.cleaned_data["cpf"].strip()
        if Profile.objects.filter(cpf=cpf).exists():
            raise forms.ValidationError("Já existe uma conta com este CPF.")
        return cpf

    @transaction.atomic
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = user.username
        if commit:
            user.save()
            Profile.objects.create(
                user=user,
                phone=self.cleaned_data["phone"],
                cpf=self.cleaned_data["cpf"],
                address=self.cleaned_data["address"],
                number_street=self.cleaned_data["number_street"],
                neighborhood=self.cleaned_data["neighborhood"],
                city=self.cleaned_data["city"],
                zip_code=self.cleaned_data["zip_code"],
            )
        return user
