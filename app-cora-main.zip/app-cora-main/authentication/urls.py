from django.contrib.auth.views import LogoutView
from django.urls import path

from .views import LoginView, RegisterView, ZipCodeLookupView

urlpatterns = [
    path("login/", LoginView.as_view(), name="login"),
    path("register/", RegisterView.as_view(), name="register"),
    path("register/cep/", ZipCodeLookupView.as_view(), name="zip_code_lookup"),
    path("logout/", LogoutView.as_view(), name="logout"),
]
