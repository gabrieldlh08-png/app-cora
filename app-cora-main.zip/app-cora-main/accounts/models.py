from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)
    cpf = models.CharField(max_length=14, unique=True)
    address = models.CharField(max_length=255)
    number_street = models.CharField(max_length=10)
    neighborhood = models.CharField(max_length=150)
    city = models.CharField(max_length=150)
    zip_code = models.CharField(max_length=10)