def user_display(request):
    user = request.user
    if not user.is_authenticated:
        return {}

    full_name = user.get_full_name().strip()
    display_name = full_name or user.first_name or user.username

    if user.first_name and user.last_name:
        initials = f"{user.first_name[0]}{user.last_name[0]}".upper()
    elif user.first_name:
        initials = user.first_name[:2].upper()
    else:
        initials = user.username[:2].upper()

    return {
        "display_name": display_name,
        "user_initials": initials,
    }
