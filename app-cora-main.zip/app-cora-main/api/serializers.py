from rest_framework import serializers

from incidents.models import Incident, IncidentPhoto


class UserSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    username = serializers.CharField()
    email = serializers.EmailField(allow_blank=True)
    first_name = serializers.CharField(allow_blank=True)
    last_name = serializers.CharField(allow_blank=True)
    is_staff = serializers.BooleanField()
    full_name = serializers.SerializerMethodField()

    def get_full_name(self, obj):
        return obj.get_full_name().strip()


class ReporterSerializer(serializers.Serializer):
    username = serializers.CharField()
    full_name = serializers.SerializerMethodField()

    def get_full_name(self, obj):
        return obj.get_full_name().strip()


class PhotoSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    class Meta:
        model = IncidentPhoto
        fields = ("id", "url")

    def get_url(self, obj):
        request = self.context.get("request")
        if not obj.image:
            return ""
        url = obj.image.url
        if request:
            return request.build_absolute_uri(url)
        return url


class IncidentSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source="get_category_display", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)
    photos = PhotoSerializer(many=True, read_only=True)
    reported_by = ReporterSerializer(read_only=True)

    class Meta:
        model = Incident
        fields = (
            "id",
            "title",
            "description",
            "category",
            "category_display",
            "status",
            "status_display",
            "address",
            "now_location",
            "created_at",
            "updated_at",
            "photos",
            "reported_by",
        )
        read_only_fields = ("id", "created_at", "updated_at", "photos", "reported_by")
