from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from . import views

urlpatterns = [
    path("auth/login/", views.LoginView.as_view()),
    path("auth/register/", views.RegisterView.as_view()),
    path("auth/refresh/", TokenRefreshView.as_view()),
    path("me/", views.MeView.as_view()),
    path("meta/", views.MetaView.as_view()),
    path("cep/<str:zip_code>/", views.CepView.as_view()),
    path("geocode/", views.GeocodeView.as_view()),
    path("home/", views.HomeView.as_view()),
    path("incidents/", views.IncidentListCreateView.as_view()),
    path("incidents/<int:pk>/", views.IncidentDetailView.as_view()),
    path("map/", views.MapView.as_view()),
    path("reports/", views.ReportsView.as_view()),
    path("alerts/", views.AlertsView.as_view()),
]
