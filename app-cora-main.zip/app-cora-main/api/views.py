from datetime import timedelta

from django.contrib.auth import authenticate
from django.db import transaction
from django.db.models import Count
from django.db.models.functions import TruncMonth
from django.utils import timezone
from rest_framework import status
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAdminUser, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from authentication.forms import RegisterForm
from dashboards.views import parse_coordinates
from incidents.models import Incident, IncidentPhoto
from incidents.views import visible_incidents
from services.alerts import recipient_emails, send_incident_confirmed_alert
from services.geocode import geocode_incident
from services.viacep import ViaCEP

from .serializers import IncidentSerializer, UserSerializer


def tokens_for(user):
    refresh = RefreshToken.for_user(user)
    return {
        "access": str(refresh.access_token),
        "refresh": str(refresh),
        "user": UserSerializer(user).data,
    }


def form_errors(form):
    errors = []
    for messages in form.errors.values():
        errors.extend(messages)
    return errors


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = (request.data.get("email") or request.data.get("username") or "").strip()
        password = request.data.get("password") or ""
        user = authenticate(username=email, password=password)
        if not user:
            return Response({"detail": "Email ou senha inválidos."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(tokens_for(user))


class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        form = RegisterForm(data=request.data)
        if not form.is_valid():
            return Response({"errors": form_errors(form)}, status=status.HTTP_400_BAD_REQUEST)
        user = form.save()
        return Response(tokens_for(user), status=status.HTTP_201_CREATED)


class MeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)


class CepView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, zip_code):
        digits = "".join(ch for ch in zip_code if ch.isdigit())
        found = ViaCEP().get_address(digits)
        if not found:
            return Response({"detail": "CEP não encontrado."}, status=status.HTTP_404_NOT_FOUND)
        return Response(
            {
                "address": found.get("logradouro") or "",
                "neighborhood": found.get("bairro") or "",
                "city": found.get("localidade") or "",
                "zip_code": found.get("cep") or "",
            }
        )


class GeocodeView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        found = geocode_incident(request.data.get("address"), request.data.get("now_location"))
        if not found:
            return Response({"detail": "Não foi possível localizar o endereço."}, status=status.HTTP_404_NOT_FOUND)
        return Response({"lat": found[0], "lng": found[1]})


class MetaView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        return Response(
            {
                "categories": list(Incident.CategoryChoices.choices),
                "statuses": list(Incident.StatusChoices.choices),
            }
        )


class HomeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        incidents = visible_incidents(request.user)
        pending = incidents.filter(status=Incident.StatusChoices.PENDING)
        in_progress = incidents.filter(status=Incident.StatusChoices.IN_PROGRESS)
        completed = incidents.filter(status=Incident.StatusChoices.COMPLETED)
        critical = incidents.filter(
            category__in=[
                Incident.CategoryChoices.FLOOD,
                Incident.CategoryChoices.LANDSLIDE,
            ]
        )
        return Response(
            {
                "incidents": IncidentSerializer(incidents[:6], many=True, context={"request": request}).data,
                "total": incidents.count(),
                "pending": pending.count(),
                "in_progress": in_progress.count(),
                "completed": completed.count(),
                "critical": critical.count(),
            }
        )


class IncidentListCreateView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get(self, request):
        incidents = visible_incidents(request.user)
        return Response(IncidentSerializer(incidents, many=True, context={"request": request}).data)

    def post(self, request):
        return _save_incident(request, None)


class IncidentDetailView(APIView):
    permission_classes = [IsAuthenticated]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get(self, request, pk):
        incident = visible_incidents(request.user).filter(pk=pk).first()
        if not incident:
            return Response({"detail": "Não encontrado."}, status=status.HTTP_404_NOT_FOUND)
        return Response(IncidentSerializer(incident, context={"request": request}).data)

    def patch(self, request, pk):
        incident = visible_incidents(request.user).filter(pk=pk).first()
        if not incident:
            return Response({"detail": "Não encontrado."}, status=status.HTTP_404_NOT_FOUND)
        return _save_incident(request, incident)

    def put(self, request, pk):
        return self.patch(request, pk)


def _files_from_request(request):
    files = request.FILES.getlist("photos") or request.FILES.getlist("photos[]")
    if not files and request.FILES.get("photos"):
        files = [request.FILES["photos"]]
    return files


def _save_incident(request, incident):
    serializer = IncidentSerializer(
        instance=incident,
        data=request.data,
        partial=bool(incident),
        context={"request": request},
    )
    serializer.is_valid(raise_exception=True)
    previous_status = incident.status if incident else None
    creating = incident is None
    with transaction.atomic():
        if creating:
            incident = Incident(reported_by=request.user, status=Incident.StatusChoices.PENDING)
        for field in ("title", "description", "category", "address", "now_location"):
            if field in serializer.validated_data:
                setattr(incident, field, serializer.validated_data[field])
        if request.user.is_staff and serializer.validated_data.get("status"):
            incident.status = serializer.validated_data["status"]
        elif creating:
            incident.status = Incident.StatusChoices.PENDING
        became_in_progress = (
            previous_status != Incident.StatusChoices.IN_PROGRESS
            and incident.status == Incident.StatusChoices.IN_PROGRESS
        )
        incident.save()
        for image in _files_from_request(request):
            IncidentPhoto.objects.create(incident=incident, image=image)
        alert_count = 0
        if became_in_progress:
            alert_count = send_incident_confirmed_alert(incident)
    return Response(
        {
            "incident": IncidentSerializer(incident, context={"request": request}).data,
            "alert_sent": became_in_progress,
            "alert_recipients": alert_count,
        }
    )


class MapView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        points = []
        for incident in visible_incidents(request.user):
            coords = parse_coordinates(incident.now_location) or parse_coordinates(incident.address)
            if not coords:
                coords = geocode_incident(incident.address, incident.now_location)
            if not coords:
                continue
            lat, lng = coords
            points.append(
                {
                    "id": incident.pk,
                    "title": incident.title,
                    "lat": lat,
                    "lng": lng,
                    "category": incident.get_category_display(),
                    "status": incident.get_status_display(),
                    "address": incident.address or incident.now_location,
                }
            )
        return Response(points)


class ReportsView(APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]

    def get(self, request):
        incidents = Incident.objects.all()
        month_names = [
            "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
            "Jul", "Ago", "Set", "Out", "Nov", "Dez",
        ]
        today = timezone.localdate()
        start_month = (today.replace(day=1) - timedelta(days=150)).replace(day=1)
        monthly_rows = {}
        for row in (
            incidents.filter(created_at__date__gte=start_month)
            .annotate(month=TruncMonth("created_at"))
            .values("month")
            .annotate(total=Count("id"))
        ):
            month = row["month"]
            if not month:
                continue
            local = timezone.localtime(month) if timezone.is_aware(month) else month
            monthly_rows[(local.year, local.month)] = row["total"]
        cursor = today.replace(day=1)
        months = []
        for _ in range(6):
            months.append(cursor)
            if cursor.month == 1:
                cursor = cursor.replace(year=cursor.year - 1, month=12)
            else:
                cursor = cursor.replace(month=cursor.month - 1)
        months.reverse()
        in_progress = Incident.objects.filter(status=Incident.StatusChoices.IN_PROGRESS)
        return Response(
            {
                "total": incidents.count(),
                "status": [
                    [label, incidents.filter(status=value).count()]
                    for value, label in Incident.StatusChoices.choices
                ],
                "category": [
                    [label, incidents.filter(category=value).count()]
                    for value, label in Incident.CategoryChoices.choices
                ],
                "trend": [
                    [f"{month_names[month.month - 1]}/{str(month.year)[2:]}", monthly_rows.get((month.year, month.month), 0)]
                    for month in months
                ],
                "in_progress": IncidentSerializer(in_progress, many=True, context={"request": request}).data,
                "recipients": len(recipient_emails()),
            }
        )


class AlertsView(ReportsView):
    pass
