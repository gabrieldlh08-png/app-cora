import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
CITY_QUERY = "Itapecerica da Serra, São Paulo, Brasil"
USER_AGENT = "CORA-TCC/1.0 (educational mapping; Itapecerica da Serra)"


def geocode_query(query):
    params = urlencode(
        {
            "q": query,
            "format": "json",
            "limit": 1,
            "countrycodes": "br",
        }
    )
    request = Request(
        f"{NOMINATIM_URL}?{params}",
        headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
    )
    with urlopen(request, timeout=12) as response:
        results = json.loads(response.read().decode())
    if not results:
        return None
    return float(results[0]["lat"]), float(results[0]["lon"])


def geocode_incident(address, now_location):
    address = (address or "").strip()
    now_location = (now_location or "").strip()
    queries = []
    if address and now_location:
        queries.append(f"{address}, {now_location}, {CITY_QUERY}")
    if address:
        queries.append(f"{address}, {CITY_QUERY}")
    if now_location:
        queries.append(f"{now_location}, {CITY_QUERY}")
    queries.append(CITY_QUERY)

    last = None
    for index, query in enumerate(dict.fromkeys(queries)):
        if index:
            time.sleep(1)
        try:
            last = geocode_query(query)
        except (HTTPError, URLError, TimeoutError, ValueError, OSError, json.JSONDecodeError):
            last = None
        if last:
            return last
    return last
