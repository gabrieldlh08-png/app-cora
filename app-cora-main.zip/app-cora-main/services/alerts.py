from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.mail import EmailMessage

from incidents.models import Incident


def recipient_emails():
    emails = set()
    for user in get_user_model().objects.filter(is_active=True):
        candidate = (user.email or user.username or "").strip()
        if "@" in candidate:
            emails.add(candidate)
    return sorted(emails)


def send_incident_confirmed_alert(incident: Incident) -> int:
    recipients = recipient_emails()
    if not recipients:
        return 0

    location = incident.address or incident.now_location or "Local não informado"
    subject = f"C.O.R.A · Alerta confirmado: {incident.title}"
    body = (
        "Um órgão responsável confirmou uma ocorrência em Itapecerica da Serra.\n"
        "O status foi atualizado para Em andamento.\n\n"
        f"Título: {incident.title}\n"
        f"Categoria: {incident.get_category_display()}\n"
        f"Local: {location}\n\n"
        f"Descrição:\n{incident.description}\n\n"
        "Fique atento e siga as orientações das autoridades locais.\n\n"
        "C.O.R.A — Central de Organização para Realocação e Acolhimento"
    )
    message = EmailMessage(
        subject=subject,
        body=body,
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "cora@localhost"),
        to=[],
        bcc=recipients,
    )
    message.send(fail_silently=True)
    return len(recipients)
