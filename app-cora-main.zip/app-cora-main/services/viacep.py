import requests


class ViaCEP:

    def __init__(self):
        self.base_url = "https://viacep.com.br/ws"

    def get_address(self, zip_code):
        zip_code = "".join(filter(str.isdigit, str(zip_code or "")))
        if len(zip_code) != 8:
            return None

        try:
            response = requests.get(f"{self.base_url}/{zip_code}/json/", timeout=8)
        except requests.RequestException:
            return None

        if response.status_code != 200:
            return None

        data = response.json()
        if data.get("erro"):
            return None
        return data
