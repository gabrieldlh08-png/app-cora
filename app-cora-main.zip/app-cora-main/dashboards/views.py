import re
from datetime import timedelta
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db.models import Count
from django.db.models.functions import TruncMonth
from django.http import HttpResponse, HttpResponseBadRequest
from django.urls import reverse
from django.utils import timezone
from django.views import View
from django.views.generic import TemplateView

from incidents.models import Incident
from incidents.views import visible_incidents
from services.geocode import geocode_incident

COORD_RE = re.compile(r"(-?\d+(?:\.\d+)?)\s*[,;]\s*(-?\d+(?:\.\d+)?)")


def parse_coordinates(value):
    if not value:
        return None
    match = COORD_RE.search(str(value))
    if not match:
        return None
    lat, lng = float(match.group(1)), float(match.group(2))
    if not (-90 <= lat <= 90 and -180 <= lng <= 180):
        return None
    return lat, lng


class HomeView(LoginRequiredMixin, TemplateView):
    def get_template_names(self):
        if self.request.user.is_staff:
            return ["dashboards/home_admin.html"]
        return ["dashboards/home_user.html"]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        incidents = visible_incidents(self.request.user)
        pending = incidents.filter(status=Incident.StatusChoices.PENDING)
        in_progress = incidents.filter(status=Incident.StatusChoices.IN_PROGRESS)
        completed = incidents.filter(status=Incident.StatusChoices.COMPLETED)
        critical = incidents.filter(
            category__in=[
                Incident.CategoryChoices.FLOOD,
                Incident.CategoryChoices.LANDSLIDE,
            ]
        )

        context.update(
            {
                "is_admin": self.request.user.is_staff,
                "incidents": incidents[:6],
                "total_count": incidents.count(),
                "pending_count": pending.count(),
                "in_progress_count": in_progress.count(),
                "completed_count": completed.count(),
                "critical_count": critical.count(),
            }
        )
        return context


class MapView(LoginRequiredMixin, TemplateView):
    template_name = "dashboards/map.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        points = []
        for incident in visible_incidents(self.request.user):
            coords = parse_coordinates(incident.now_location) or parse_coordinates(
                incident.address
            )
            if not coords:
                coords = geocode_incident(incident.address, incident.now_location)
            if not coords:
                continue
            lat, lng = coords
            points.append(
                {
                    "id": incident.pk,
                    "title": incident.title,
                    "lat": lat,
                    "lng": lng,
                    "category": incident.get_category_display(),
                    "status": incident.get_status_display(),
                    "address": incident.address or incident.now_location,
                    "url": reverse("incident_update", args=[incident.pk]),
                }
            )
        context.update(
            {
                "is_admin": self.request.user.is_staff,
                "map_points": points,
                "point_count": len(points),
            }
        )
        return context


class MapTileView(LoginRequiredMixin, View):
    """Serve OSM tiles with an identifying User-Agent so volunteer servers allow them."""



    def get(self, request, z, x, y):
        if z < 0 or z > 19 or x < 0 or y < 0:
            return HttpResponseBadRequest()
        max_index = (1 << z) - 1
        if x > max_index or y > max_index:
            return HttpResponseBadRequest()

        url = f"https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        req = Request(
            url,
            headers={
                "User-Agent": "CORA-TCC/1.0 (educational mapping; Itapecerica da Serra)",
                "Accept": "image/png,image/*",
            },
        )
        try:
            with urlopen(req, timeout=12) as response:
                data = response.read()
                content_type = response.headers.get("Content-Type", "image/png")
        except (HTTPError, URLError, TimeoutError, ValueError, OSError):
            return HttpResponse(status=502)

        http = HttpResponse(data, content_type=content_type)
        http["Cache-Control"] = "public, max-age=86400"
        return http


class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_staff


class AlertsView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    template_name = "dashboards/alerts.html"

    def get_context_data(self, **kwargs):
        from services.alerts import recipient_emails

        context = super().get_context_data(**kwargs)
        context.update(
            {
                "is_admin": True,
                "in_progress_incidents": Incident.objects.filter(
                    status=Incident.StatusChoices.IN_PROGRESS
                ),
                "recipient_count": len(recipient_emails()),
            }
        )
        return context


class ReportsView(LoginRequiredMixin, StaffRequiredMixin, TemplateView):
    template_name = "dashboards/reports.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        incidents = Incident.objects.all()
        month_names = [
            "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
            "Jul", "Ago", "Set", "Out", "Nov", "Dez",
        ]
        today = timezone.localdate()
        start_month = (today.replace(day=1) - timedelta(days=150)).replace(day=1)
        monthly_rows = {}
        for row in (
            incidents.filter(created_at__date__gte=start_month)
            .annotate(month=TruncMonth("created_at"))
            .values("month")
            .annotate(total=Count("id"))
        ):
            month = row["month"]
            if not month:
                continue
            local = timezone.localtime(month) if timezone.is_aware(month) else month
            monthly_rows[(local.year, local.month)] = row["total"]
        trend_labels = []
        trend_values = []
        cursor = today.replace(day=1)
        months = []
        for _ in range(6):
            months.append(cursor)
            if cursor.month == 1:
                cursor = cursor.replace(year=cursor.year - 1, month=12)
            else:
                cursor = cursor.replace(month=cursor.month - 1)
        months.reverse()
        for month in months:
            trend_labels.append(f"{month_names[month.month - 1]}/{str(month.year)[2:]}")
            trend_values.append(monthly_rows.get((month.year, month.month), 0))

        status_labels = []
        status_values = []
        for value, label in Incident.StatusChoices.choices:
            status_labels.append(label)
            status_values.append(incidents.filter(status=value).count())

        category_labels = []
        category_values = []
        for value, label in Incident.CategoryChoices.choices:
            category_labels.append(label)
            category_values.append(incidents.filter(category=value).count())

        context.update(
            {
                "is_admin": True,
                "total_count": incidents.count(),
                "status_chart": {"labels": status_labels, "values": status_values},
                "category_chart": {"labels": category_labels, "values": category_values},
                "trend_chart": {"labels": trend_labels, "values": trend_values},
            }
        )
        return context
