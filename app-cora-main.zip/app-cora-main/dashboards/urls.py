from django.urls import path

from .views import AlertsView, HomeView, MapTileView, MapView, ReportsView

urlpatterns = [
    path("", HomeView.as_view(), name="home"),
    path("mapa/tiles/<int:z>/<int:x>/<int:y>.png", MapTileView.as_view(), name="map_tile"),
    path("mapa/", MapView.as_view(), name="map"),
    path("alertas/", AlertsView.as_view(), name="alerts"),
    path("relatorios/", ReportsView.as_view(), name="reports"),
]
