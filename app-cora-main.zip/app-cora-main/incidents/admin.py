from django.contrib import admin

from .models import Incident, IncidentPhoto


class IncidentPhotoInline(admin.TabularInline):
    model = IncidentPhoto
    extra = 1


@admin.register(Incident)
class IncidentAdmin(admin.ModelAdmin):
    list_display = ("title", "category", "status", "reported_by", "created_at")
    inlines = [IncidentPhotoInline]
