from django import forms
from django.db import transaction
from django.forms import inlineformset_factory

from .models import Incident, IncidentPhoto


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleImageField(forms.ImageField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault(
            "widget",
            MultipleFileInput(attrs={"accept": "image/*", "multiple": True}),
        )
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single_file_clean = super().clean
        if isinstance(data, (list, tuple)):
            return [single_file_clean(item, initial) for item in data]
        result = single_file_clean(data, initial)
        return [] if result in (None, "") else [result]


class IncidentForm(forms.ModelForm):
    photos = MultipleImageField(label="Fotos", required=False)

    class Meta:
        model = Incident
        fields = (
            "title",
            "description",
            "category",
            "status",
            "address",
            "now_location",
        )
        labels = {
            "title": "Título",
            "description": "Descrição",
            "category": "Categoria",
            "status": "Status",
            "address": "Endereço",
            "now_location": "Localização atual",
        }

    def __init__(self, *args, user=None, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)
        if not self.instance.pk:
            self.fields["status"].initial = Incident.StatusChoices.PENDING
        if not getattr(self.user, "is_staff", False):
            self.fields.pop("status", None)

    @transaction.atomic
    def save(self, commit=True):
        previous_status = None
        if self.instance.pk:
            previous_status = (
                Incident.objects.filter(pk=self.instance.pk)
                .values_list("status", flat=True)
                .first()
            )
        incident = super().save(commit=False)
        if self.user and not incident.pk:
            incident.reported_by = self.user
        if "status" not in self.fields and not incident.status:
            incident.status = Incident.StatusChoices.PENDING
        if not incident.status:
            incident.status = Incident.StatusChoices.PENDING
        became_in_progress = (
            previous_status != Incident.StatusChoices.IN_PROGRESS
            and incident.status == Incident.StatusChoices.IN_PROGRESS
        )
        self.alert_sent = False
        self.alert_recipients = 0
        if commit:
            incident.save()
            self.save_photos(incident)
            if became_in_progress:
                from services.alerts import send_incident_confirmed_alert

                self.alert_recipients = send_incident_confirmed_alert(incident)
                self.alert_sent = True
        return incident

    def save_photos(self, incident):
        images = self.cleaned_data.get("photos") or []
        for image in images:
            IncidentPhoto.objects.create(incident=incident, image=image)


class IncidentPhotoForm(forms.ModelForm):
    class Meta:
        model = IncidentPhoto
        fields = ("image",)
        labels = {"image": "Foto"}


IncidentPhotoFormSet = inlineformset_factory(
    Incident,
    IncidentPhoto,
    form=IncidentPhotoForm,
    extra=1,
    can_delete=True,
)
