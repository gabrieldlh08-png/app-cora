from django.conf import settings
from django.db import models


class Incident(models.Model):
    class CategoryChoices(models.TextChoices):
        FLOOD = "FLOOD", "Inundação"
        RISK_HOUSING = "RISK_HOUSING", "Risco de moradia"
        LANDSLIDE = "LANDSLIDE", "Deslizamento de terra"
        INFRASTRUCTURE_FAILURE = "INFRASTRUCTURE_FAILURE", "Falha de infraestrutura"
        OTHER = "OTHER", "Outro"

    class StatusChoices(models.TextChoices):
        PENDING = "PENDING", "Pendente"
        IN_PROGRESS = "IN_PROGRESS", "Em andamento"
        COMPLETED = "COMPLETED", "Concluído"
        CANCELLED = "CANCELLED", "Cancelado"

    title = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=255, choices=CategoryChoices.choices)
    status = models.CharField(max_length=255, choices=StatusChoices.choices)
    address = models.CharField(max_length=255)
    now_location = models.CharField(max_length=255)
    reported_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="incidents",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ["-created_at"]


class IncidentPhoto(models.Model):
    incident = models.ForeignKey(
        Incident,
        on_delete=models.CASCADE,
        related_name="photos",
    )
    image = models.ImageField(upload_to="incidents/photos/")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.image.name
