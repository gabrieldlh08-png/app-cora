from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView

from .forms import IncidentForm
from .models import Incident


def visible_incidents(user):
    queryset = Incident.objects.select_related("reported_by").prefetch_related("photos")
    if user.is_staff:
        return queryset
    return queryset.filter(reported_by=user)


class IncidentContextMixin:
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["is_admin"] = self.request.user.is_staff
        return context


class IncidentQuerysetMixin(IncidentContextMixin):
    def get_queryset(self):
        return visible_incidents(self.request.user)


class IncidentFormMixin:
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        return kwargs


class IncidentListView(LoginRequiredMixin, IncidentQuerysetMixin, ListView):
    model = Incident
    template_name = "incidents/incident_list.html"
    context_object_name = "incidents"


class IncidentCreateView(LoginRequiredMixin, IncidentContextMixin, IncidentFormMixin, CreateView):
    model = Incident
    form_class = IncidentForm
    template_name = "incidents/incident_form.html"
    success_url = reverse_lazy("incident_list")


class IncidentUpdateView(
    LoginRequiredMixin, IncidentQuerysetMixin, IncidentFormMixin, UpdateView
):
    model = Incident
    form_class = IncidentForm
    template_name = "incidents/incident_form.html"
    success_url = reverse_lazy("incident_list")

    def form_valid(self, form):
        response = super().form_valid(form)
        if getattr(form, "alert_sent", False):
            count = getattr(form, "alert_recipients", 0)
            messages.success(
                self.request,
                f"Ocorrência confirmada. Alerta enviado por e-mail para {count} morador(es).",
            )
        return response
