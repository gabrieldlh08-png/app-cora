from django.urls import path

from .views import IncidentCreateView, IncidentListView, IncidentUpdateView

urlpatterns = [
    path("", IncidentListView.as_view(), name="incident_list"),
    path("nova/", IncidentCreateView.as_view(), name="incident_create"),
    path("<int:pk>/editar/", IncidentUpdateView.as_view(), name="incident_update"),
]
