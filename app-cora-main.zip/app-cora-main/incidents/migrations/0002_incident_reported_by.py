import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


def assign_existing_incidents(apps, schema_editor):
    User = apps.get_model("auth", "User")
    Incident = apps.get_model("incidents", "Incident")
    user = User.objects.order_by("id").first()
    if user:
        Incident.objects.filter(reported_by__isnull=True).update(reported_by=user)


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("incidents", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="incident",
            name="reported_by",
            field=models.ForeignKey(
                null=True,
                on_delete=django.db.models.deletion.CASCADE,
                related_name="incidents",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.RunPython(assign_existing_incidents, migrations.RunPython.noop),
        migrations.AlterField(
            model_name="incident",
            name="reported_by",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.CASCADE,
                related_name="incidents",
                to=settings.AUTH_USER_MODEL,
            ),
        ),
    ]
